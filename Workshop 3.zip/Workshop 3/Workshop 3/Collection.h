#pragma once


#include <iosream>



template<typename T, typename C>

class Collection 

{



private:

	T m_items[];

	C collectionCapacity;


	T m_smallestItem;

	T m_largestItem;


	setSmallestItem()
	{

			

	}


	setLargestItem()
	{



	}

	
public:



	T getSmallestItem() {



	}




	T getLargestItem() {



	}



	void size()

	{




	}


	void capacity()
	{




	}



	bool operator+=()

	{




	}


	void print() {





	}
	





};
